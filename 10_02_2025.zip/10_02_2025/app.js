const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
    res.send('<h1>Witaj na mojej stronie!</h1>');
});

app.listen(port, () => {
    console.log(`Serwer działa na http://localhost:${port}`);
});